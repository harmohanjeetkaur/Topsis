ASSIGNMENT 4
Develop a command line python program to implement the Topsis.

#installation 
pip install harmohanjeet

